1. کتابخانه‌های لازم را نصب کنید:
   pip install -r requirements.txt

2. متغیر BOT_TOKEN را تنظیم کنید:
   Windows:
       set BOT_TOKEN=توکن_ربات
   Linux/Mac:
       export BOT_TOKEN=توکن_ربات

3. ربات را اجرا کنید:
   python bot.py

4. برای ورود به پنل مدیریت:
   /admin را در چت با ربات ارسال کنید.
